
At the time of release the majority of the User Guide & Help for QueueZee v2 has not been updated
from v1.3. Until such time when these updates have taken place this document will prove useful for
listing all the new features in QueueZee v2. Although these new features should also be fairly
intuitive to use please contact AngusSoft (support@AngusSoft.co.uk) for any questions or queries.

(Needless to say support via donations for the fully featured version will always help things along!)

New Features in QueueZee v2
===========================

	* Running QueueZee on most Unix platforms is supported, (it's been used extensively on Fedora).
	
	* Double clicking in the message Data or RFH2 window will show the text in a resizable
	  separate window. Edits can then be confirmed (click [Ok]) or cancelled by simply 
	  closing the window.

	* Selected Queue Manager details can be copied to the clipboard.

	* Basic local Queues can be created on Queue Managers and Queue Manager definitions can be
	  imported.

	* Queue Manager definitions can be automatically imported by asking QueueZee to discover
	  them on the selected Queue Manager (the selected Queue Manager must be connected).

	* Message properties are shown as XML elements to support MQ v7 headers.

	* Clustered Queues are supported and will be shown if you have any.

	* You can delete Queues that don't have any messages or connections from the Queue list.

	* You can create a basic message and put it on a Queue from scratch. This can then be
	  edited and copied as needed.

	* You can move copied messages in addition to just copying them, (saves copying and
	  deleting).

	* You can create virtual Queues which will behave like real Queues but are actually just
	  locally stored files so an easy way to have access to the same messages across multiple
	  Queue Managers. Virtual Queues can only be created in custom folders.

	* You can redirect messages from one Queue to another while your instance of QueueZee
	  remains running.

	* The Queue monitoring panel from the SandPit will now still run while returning control
	  back to the main GUI so you have multiple monitor panels and still do other QueueZee
	  work while they're running.

	* A very basic compare feature is provided for copied messages.

	* A search feature is provided to search for strings within displayed message data. The
	  value to search for must be entered in the existing message search window, (the one 
	  next to the torch icon on the Queue and Message tool-bar!).

	* A Queue shark feature is provided to able the user to see some messages going through
	  active Queues. There is no guarantee what messages QueueZee will manage to capture with
	  this feature and it depends a lot on other variables like how many other applications are
	  reading the Queue. Generally though the performance impact is not significant and you're
	  likely to capture more messages on busy Queues.

	* Lots of internal improvements and bug fixes.

	* Lots of improvements to existing features.

	* Message report settings are now available and editable along with other newly editable
	  fields including persistence, encoding and character set.
	  
	* Automated Queue clear-down option for Queue monitoring from the Sandbox.
	
	* Detailed and specific debug paths can now be selected using configurable debug tags
	  from the Preferences dialog.
	
	* The message pop-up menu has a new option to show the messages in the sequence they 
	  are on the Queue (i.e. unsort them). This is useful if you have sorted on a particular
	  column and want to see the natural ordering again.
	  
	* The message pop-up has another new option to change various MQMD properties on the
	  selected messages. This is very useful for doing bulk MQMD changes, (for example,
	  changing the message type or reply to Queue).
	  
	* The existing compare copied messages feature has been extended to analyse the message
	  XML structure so even if the copied messages aren�t identical QueueZee will tell you
	  if the XML structure is identical and if not, how it differs.
	  
	* The Queue Redirect feature has been extended to allow browsed (the default) and
	  destructive reads. It will also allow you to look for specific messages now based
	  on either a provided message id or correlation id.
	  
	*  The Queue Manager properties (Queue Manager pop-up menu) now includes an option to
	   provide a custom Queue list. If this list isn't empty QueueZee will only attempt
	   to access and display the Queues in the list. The list should be cleared to return
	   to the automated Queue discovery mode where all available Queues are shown.
	   
	*  Virtual Queues have been extended to support Oracle Database tables or views.
	
	*  An extra button has been added to the full message search (between the search box
	   and the date search button) which will provide a large edit window for long
	   search strings.
	   
	*  Three options have been added to the General Preferences which let you set the
	   default column and sort order for the Queue Manager, Queue and Message tables.
	   
	*  An extra option to the Queue pop-up menu shows you the Queue properties (mainly
	   useful for Oracle DB virtual Queues).
	   
	*  A new feature has been added to the Messages pop-up menu which will allow copied
	   messages to be pasted to any Queues in the SandPit residing on connected Queue
	   Managers. This is very useful as a much quicker way of repetitive pasting across
	   different Queue Managers (although it can obviously also be the same Queue
	   Manager!).
	      