======================================================================================
Copyright � 2012, Angus Cooke
Copyright � 2012, AngusSoft
All rights reserved.

Redistribution of the QueueZee v2.x package, without modification, is permitted
provided that the following conditions are met:

Neither the name of QueueZee nor the name of AngusSoft may be used to endorse
or promote products developed or tested using this software without specific
prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS "AS IS" AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY
WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
DAMAGE.
======================================================================================

QueueZee v2.x Installation
--------------------------

If you're reading this I'm assuming you have already downloaded/copied the QueueZee v2.x
zip file and unzipped it somewhere suitable, (the recommended location is somewhere
like "C:\Program Files\QueueZee_v2").

IMPORTANT!!: QueueZee v2.x uses the IBM WebSphere MQ v7.0 Java client libraries so it
won't work with the WMQ v6 libraries. Also, as a result of this if you have any messages
exported in XStream format from QueueZee v1.x you won't be able to import them into
QueueZee v2.x - you must import them to a Queue using QueueZee v1.x first then you can
export them again using QueueZee v2.x.

To complete the installation you must copy your IBM WebSphere MQ v7.0 Java client classes
to the QueueZee lib directory. These are:

com.ibm.mq.commonservices.jar
com.ibm.mq.headers.jar
com.ibm.mq.jar
com.ibm.mq.jmqi.jar
com.ibm.mq.pcf.jar
connector.jar

Which are normally found in the following location:

<Your_IBM_WebSphere_MQ_v7_Install_Path>\Java\lib

For example, this might be:

"C:\Program Files\IBM\WebSphere MQ\Java\lib"

TIP: The qz.bat file will copy these files across for you if they reside in the above
     directory or the equivalent Windows v7 path.

If you unzipped qzv2.3.zip to "C:\Program Files\QueueZee_v2" then the lib directory should
now look something like this:

C:\Program Files\QueueZee_v2\lib\com.ibm.mq.commonservices.jar
C:\Program Files\QueueZee_v2\lib\com.ibm.mq.headers.jar
C:\Program Files\QueueZee_v2\lib\com.ibm.mq.jar
C:\Program Files\QueueZee_v2\lib\com.ibm.mq.jmqi.jar
C:\Program Files\QueueZee_v2\lib\com.ibm.mq.pcf.jar
C:\Program Files\QueueZee_v2\lib\connector.jar
C:\Program Files\QueueZee_v2\lib\ojdbc6.jar
C:\Program Files\QueueZee_v2\lib\qz.jar
C:\Program Files\QueueZee_v2\lib\xpp3-1.1.3.4.C.jar
C:\Program Files\QueueZee_v2\lib\xstream-1.1.3.jar

Once you have the correct Java library files in place you must check you have Java v1.6
or above installed as the default JRE (Java Runtime Environment). QueueZee v2.x needs
this in order to run. You can check what version of Java is installed by typing
"java -version" at a Windows command prompt, (available from a command window).

If it all looks good, double click on the qz.bat file in the QueueZee home directory, (the
directory this file is in), and QueueZee will start.

IMPORTANT: QueueZee v2.x will also run on most Unix platforms and I have provided a sample
qz.sh shell script alternative to the qz.bat for general use. I have not provided any
specific instructions for running QueueZee v2.x on Unix as other than using the shell script
to start it the rest should be fairly obvious. There should be no other changes required.

Although QueueZee v2.x is Freeware you still need an access key to use the fully featured
version. To obtain an access key you must make a donation (there is no minimum amount for
a donation). QueueZee can be used in browse only mode without an access key for an
unlimited period.

To request an access key the access key information displayed in the Access Key dialog 
which appears on start-up must be copied (Ctrl-v) and sent to admin@AngusSoft.co.uk. 


IMPORTANT: Please provide your name & location (i.e. Edinburgh, UK) and if it isn't
obvious from your email address or name, a reference for your donation.
Your access key will be returned and will work on a per-host basis so only one need be 
requested per computer, (up to 5 access keys can be requested from one donation).
Please keep your key in a safe place as you may need it again if upgrades to your
computer remove the original key store. There is no limit to the amount of key
requests per person or company, (as per the donation rules).


If you would like to evaluate QueueZee immediately without waiting for an access key you
can tick (click on) the browse only mode check-box when the access key dialog first appears. 
This will allow QueueZee to work in browse only mode for an indefinite period, (if you
want full access you must request an access key).


A separate configuration file is maintained per user on the same computer so several logins
can use QueueZee on the same installation.

Within your QueueZee home directory there is a "QueueZee_v2.pdf" file which contains a
PDF version of the Windows help file, (queuezee.chm). This is a simple page by page
conversion from the CHM file.

IMPORTANT: So far very little of the help document has been updated from QueueZee v1.3.
Much of it is still relevant and updates are ongoing subject to time available. Please
email support@AngusSoft.co.uk if you have any specific queries.


Finally, thank-you for choosing QueueZee v2.x and I hope it you find it useful within 
your organisation for your WMQ development projects.

For any problems, suggestions or donations please go to AngusSoft.co.uk or contact us
at support@AngusSoft.co.uk.

FINALLY: Needless to say a awful lot of time and work has gone in to creating QueueZee
and as such donations are very gratefully received - I am much more inclined to provide
support and documentation updates if my efforts are recognised!


Thank-you

Angus Cooke.
