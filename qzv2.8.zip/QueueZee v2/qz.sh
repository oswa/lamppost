#!/bin/bash
set -x

export CLASSPATH=./lib/qz.jar
export CLASSPATH=$CLASSPATH:./lib/com.ibm.mq.jar
export CLASSPATH=$CLASSPATH:./lib/com.ibm.mq.jmqi.jar
export CLASSPATH=$CLASSPATH:./lib/com.ibm.mq.commonservices.jar
export CLASSPATH=$CLASSPATH:./lib/com.ibm.mq.headers.jar
export CLASSPATH=$CLASSPATH:./lib/connector.jar
export CLASSPATH=$CLASSPATH:./lib/com.ibm.mq.pcf.jar

export CLASSPATH=$CLASSPATH:./lib/xstream-1.1.3.jar
export CLASSPATH=$CLASSPATH:./lib/xpp3-1.1.3.4.C.jar
export CLASSPATH=$CLASSPATH:./lib/ojdbc6.jar

nohup java -Xms64m -Xmx1024m uk.angussoft.qz.QZMain &