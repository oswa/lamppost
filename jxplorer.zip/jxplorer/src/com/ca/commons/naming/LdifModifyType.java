package com.ca.commons.naming;

public enum LdifModifyType
{
    add, delete, replace, test;  // note; we use the string values in print outs, so don't change capitalisation..!
}
