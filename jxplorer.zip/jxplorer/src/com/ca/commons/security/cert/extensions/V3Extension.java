
package com.ca.commons.security.cert.extensions;

import com.ca.commons.security.asn1.*;

/**
 * <pre>
 *
 * </pre>
 *
 * @author vbui
 */
public interface V3Extension
{
    public abstract void init(ASN1Object asn1object) throws Exception;
}

